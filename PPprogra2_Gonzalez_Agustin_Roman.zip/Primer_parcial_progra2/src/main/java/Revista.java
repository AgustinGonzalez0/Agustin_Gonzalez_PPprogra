/*
 * Clase que representa una revista, hereda de Publicacion
 * Las revistas tienen un numero de edicion
 */
public class Revista extends Publicacion {
    private int numeroEdicion;

    /*
     * Constructor para inicializar una revista con su titulo, año de publicacion y numero de edicion
     * @param titulo El titulo de la revista
     * @param anioPublicacion El año en que se publico la revista
     * @param numeroEdicion El numero de edicion de la revista
     */
    public Revista(String titulo, int anioPublicacion, int numeroEdicion) {
        super(titulo, anioPublicacion);
        this.numeroEdicion = numeroEdicion;
    }

    /*
     * Sobrescribe el metodo toString() para proporcionar una descripcion de la revista
     * @return Una cadena con los detalles de la revista, incluyendo su numero de edicion
     */
    @Override
    public String toString() {
        return "Revista [titulo=" + titulo + ", numero de edicion=" + numeroEdicion + ", año de publicacion=" + anioPublicacion + "]";
    }

    /**
     * Metodo para simular la lectura de una revista
     * @return Un mensaje indicando que la revista se esta leyendo
     */
    public String leer() {
        return "Leyendo la revista: " + titulo + " edicion " + numeroEdicion;
    }
}
