/* Enumerado que representa los géneros literarios de un libro.*/
public enum Genero {
    FICCION, NO_FICCION, CIENCIA, HISTORIA
}
