/*Excepción personalizada que se lanza cuando se intenta agregar una publicacion duplicada a la biblioteca*/
public class PublicacionDuplicadaException extends Exception {
    public PublicacionDuplicadaException(String mensaje) {
        super(mensaje);
    }
}
