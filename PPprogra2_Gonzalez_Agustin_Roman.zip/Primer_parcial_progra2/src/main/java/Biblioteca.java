import java.util.HashSet;
import java.util.Set;

public class Biblioteca {

    private Set<Publicacion> publicaciones;

    public Biblioteca() {
        publicaciones = new HashSet<>();
    }

    /*
     * Mtodo que permite agregar una publicación a la biblioteca.
     * Lanza una excepcion si la publicacion ya existe (mismo título y año).
     */
    public void agregarPublicacion(Publicacion publicacion) throws PublicacionDuplicadaException {
        if (publicaciones.contains(publicacion)) {
            throw new PublicacionDuplicadaException("La publicación ya existe en la biblioteca.");
        }
        publicaciones.add(publicacion);
    }

    /*
     * Metodo que muestra todas las publicaciones en la biblioteca
     * Utiliza el metodo toString() de cada tipo de publicacion para imprimir sus detalles
     */
    public void mostrarPublicaciones() {
        for (Publicacion publicacion : publicaciones) {
            System.out.println(publicacion.toString()); // Llama a toString() de cada publicacon
        }
    }
}
