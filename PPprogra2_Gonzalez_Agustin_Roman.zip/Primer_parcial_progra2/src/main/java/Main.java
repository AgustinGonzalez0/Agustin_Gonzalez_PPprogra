public class Main {
    public static void main(String[] args) {
        // Crear instancia de la biblioteca
        Biblioteca biblioteca = new Biblioteca();

        // Crear algunas publicaciones
        Publicacion libro1 = new Libro("La Odisea", 800, "Homero", Genero.FICCION);
        Publicacion revista1 = new Revista("National Geographic", 2023, 345);
        Publicacion ilustracion1 = new Ilustracion("Paisaje", 1950, "Quinquela Martín", 125, 105);

        try {
            // Agregar publicaciones a la biblioteca
            biblioteca.agregarPublicacion(libro1);
            biblioteca.agregarPublicacion(revista1);
            biblioteca.agregarPublicacion(ilustracion1);

            // Mostrar todas las publicaciones
            System.out.println("Publicaciones en la biblioteca:");
            biblioteca.mostrarPublicaciones();
            
        } catch (PublicacionDuplicadaException e) {
            System.err.println(e.getMessage());
        }
    }
}
