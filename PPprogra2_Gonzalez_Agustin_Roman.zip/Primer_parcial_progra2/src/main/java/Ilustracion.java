/*
 * Clase que representa una ilustracion, hereda de Publicacion
 * Las ilustraciones tienen un ilustrador y unas dimensiones especificas (ancho y alto)
 */
public class Ilustracion extends Publicacion {
    private String ilustrador;
    private double ancho;
    private double alto;

    /*
     * Constructor para inicializar una ilustracion con su titulo, año de publicacion, ilustrador, ancho y alto
     * @param titulo El titulo de la ilustracion
     * @param anioPublicacion El año en que se publico la ilustracion
     * @param ilustrador El nombre del ilustrador
     * @param ancho El ancho de la ilustracion
     * @param alto El alto de la ilustracion
     */
    public Ilustracion(String titulo, int anioPublicacion, String ilustrador, double ancho, double alto) {
        super(titulo, anioPublicacion);
        this.ilustrador = ilustrador;
        this.ancho = ancho;
        this.alto = alto;
    }

    /**
     * Sobrecribe el metodo toString() para proporcionar una descripcion de la ilustracion
     * @return Una cadena con los detalles de la ilustracin, como ilustrador y dimensiones
     */
    @Override
    public String toString() {
        return "Ilustracion [titulo=" + titulo + ", ilustrador=" + ilustrador + ", dimensiones=" + ancho + "x" + alto + ", año de publicacion=" + anioPublicacion + "]";
    }
}
