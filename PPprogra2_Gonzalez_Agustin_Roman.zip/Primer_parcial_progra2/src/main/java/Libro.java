/**
 * Clase que representa un libro, hereda de Publicacion
 * Los libros tienen un autor y pertenecen a un genero especifico
 */
public class Libro extends Publicacion {
    private String autor;
    private Genero genero;

    /**
     * Constructor para inicializar un libro con su titulo, año de publicacion, autor y genero
     * @param titulo El titulo del libro
     * @param anioPublicacion El año en que se publico el libro
     * @param autor El autor del libro
     * @param genero El genero del libro
     */
    public Libro(String titulo, int anioPublicacion, String autor, Genero genero) {
        super(titulo, anioPublicacion);
        this.autor = autor;
        this.genero = genero;
    }

    /**
     * Sobrescribe el metodo toString() para proporcionar una descripcion del libro
     * @return Una cadena con los detalles del libro, como autor y genero
     */
    @Override
    public String toString() {
        return "Libro [titulo=" + titulo + ", autor=" + autor + ", genero=" + genero + ", año de publicacion=" + anioPublicacion + "]";
    }

    /**
     * Metodo para simular la lectura de un libro
     * @return Un mensaje indicando que el libro se esta leyendo
     */
    public String leer() {
        return "Leyendo el libro: " + titulo + " de " + autor;
    }
}
