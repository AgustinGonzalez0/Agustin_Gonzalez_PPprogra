/*
 * Clase base para representar una publicacion en la biblioteca
 * Tiene atributos comunes a todas las publicaciones como titulo y año de publicacion
 */
public abstract class Publicacion {
    protected String titulo;
    protected int anioPublicacion;

    /*
     * Constructor para inicializar una publicacion con su titulo y año de publicacion
     * @param titulo El titulo de la publicacion
     * @param anioPublicacion El año en que se publico la publicacion
     */
    public Publicacion(String titulo, int anioPublicacion) {
        this.titulo = titulo;
        this.anioPublicacion = anioPublicacion;
    }

    /*
     * Sobrescribe el metodo hashCode() para permitir la comparacion basada en el titulo y año de publicacion
     * @return Codigo hash basado en el titulo y el año de publicacion
     */
    @Override
    public int hashCode() {
        return titulo.hashCode() + anioPublicacion;
    }

    /*
     * Sobrescribe el metodo equals() para comparar publicaciones por su titulo y año de publicacion
     * @param obj El objeto a comparar
     * @return true si las publicaciones tienen el mismo titulo y año de publicacion, de lo contrario false
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Publicacion that = (Publicacion) obj;
        return anioPublicacion == that.anioPublicacion && titulo.equals(that.titulo);
    }

    /**
     * Mtodo abstracto para obtener una representacion de la publicacion como cadena
     * Cada subclase debe implementar su propia version de este metodo
     * @return Representacion en texto de la publicacion
     */
    @Override
    public abstract String toString();
}
